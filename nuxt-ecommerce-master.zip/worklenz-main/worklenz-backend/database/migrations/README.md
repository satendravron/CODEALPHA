Migrations should be executed out in the sequence specified by the filename. They should be removed once the migrations
have been released to all databases.
