cd "PATH_HERE"
npm ci
npm run build
