import Vue from 'vue'
import VueSwal from 'vue-swal'

Vue.use(VueSwal)
