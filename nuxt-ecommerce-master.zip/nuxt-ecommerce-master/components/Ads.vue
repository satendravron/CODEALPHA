<template>
  <div class="bg-primary ads flex justify-center items-center">
    <h3 class="text-white text-lg ml-6 sm:text-2xl font-bold">
      50% off on all Purchases Above $300, Hurry Now!!!!
    </h3>
    <img
      class="h-48 sm:pl-20"
      :src="`uriel-soberanes-MxVkWPiJALs-unsplash-removebg-preview.png`"
      alt=""
    />
  </div>
</template>

<script>
export default {
  name: 'Ads',
}
</script>

<style scpoed></style>
