module.exports = {
  theme: {
    backgroundColor: (theme) => ({
      ...theme('colors'),
      primary: '#9c7474',
      button: '#bec1a6',
    }),
  },
}
