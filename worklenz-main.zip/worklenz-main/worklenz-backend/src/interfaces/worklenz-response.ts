import {Response} from "express";

export type IWorkLenzResponse = Response
