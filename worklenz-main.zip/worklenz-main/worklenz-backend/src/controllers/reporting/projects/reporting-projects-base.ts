import ReportingControllerBase from "../reporting-controller-base";

export default class ReportingProjectsBase extends ReportingControllerBase {
}
