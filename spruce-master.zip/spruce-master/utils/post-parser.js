var mongoose = require("mongoose");
var user = require("./models/user");
var fs = require("fs");
